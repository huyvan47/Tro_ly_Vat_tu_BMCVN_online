from rag.fusion import fuse_and_select_raw
from rag.builder import build_results_from_raw
from rag.retriever import search as retrieve_search
from typing import cast


def multi_hop_controller(
    *,
    client,
    kb,
    base_query: str,
    must_tags,
    any_tags,
):
    top_k = 80

    # HOP 1
    hop1 = retrieve_search(
        client=client,
        kb=kb,
        norm_query=base_query,
        top_k=top_k,
        must_tags=must_tags,
        any_tags=[],
        return_raw=True,
    )
    hop1 = cast(dict, hop1)
    raw1 = hop1["raw"]
    sims = hop1["sims"]

    # HOP 2
    hop2_query = f"hoạt chất trị {base_query}"
    hop2 = retrieve_search(
        client=client,
        kb=kb,
        norm_query=hop2_query,
        top_k=top_k,
        must_tags=[],
        any_tags=any_tags,
        return_raw=True,
    )
    hop2 = cast(dict, hop2)
    raw2 = hop2["raw"]

    # FUSION
    all_raw = raw1 + raw2
    final_raw = fuse_and_select_raw(all_raw, max_docs=32)

    # BUILD RESULTS FOR LLM
    final_results = build_results_from_raw(final_raw, kb, sims)

    return final_results
