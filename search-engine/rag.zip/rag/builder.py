def build_results_from_raw(raw_rows, kb, sims):
    EMBS, QUESTIONS, ANSWERS, ALT_QUESTIONS, CATEGORY, TAGS, IDS, TAGS_V2, ENTITY_TYPE = kb

    results = []
    for row in raw_rows:
        i = row["idx"]
        item = {
            "id": str(IDS[i]),
            "question": str(QUESTIONS[i]),
            "answer": str(ANSWERS[i]),
            "score": float(sims[i]),
            "tags_v2": str(TAGS_V2[i]) if TAGS_V2 is not None else "",
        }
        results.append(item)
    return results
