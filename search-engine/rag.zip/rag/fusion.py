def fuse_and_select_raw(all_raw, max_docs=32):
    pass_rows = [r for r in all_raw if r["pass"]]
    fail_rows = [r for r in all_raw if not r["pass"]]

    pass_rows.sort(key=lambda x: (x["tag_score"], x["sim"]), reverse=True)
    fail_rows.sort(key=lambda x: x["sim"], reverse=True)

    final = []
    final.extend(pass_rows)

    if len(final) < max_docs:
        final.extend(fail_rows[: max_docs - len(final)])

    return final[:max_docs]
